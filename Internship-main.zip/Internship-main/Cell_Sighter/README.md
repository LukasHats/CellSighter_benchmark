# CellSighter

The original code for CellSighter is available at this link: https://github.com/KerenLab/CellSighter,
was adapted by mahmoodlab, which is available at this link: https://github.com/mahmoodlab/MAPS/tree/main/scripts/CellSighter
and further adapted by me.

The codes contain short scripts to train CellSighter on different datasets.
